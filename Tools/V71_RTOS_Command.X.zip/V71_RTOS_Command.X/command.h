#ifndef COMMAND_H    /* Guard against multiple inclusion */
#define COMMAND_H

/* Includes */
// Header
#include "atmel_start_pins.h"
#include "atmel_start.h"

// C Library
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* Definitions */
#define COMMAND_ADDRESS 0x72

/* Typedef */
typedef struct packet_t{
  uint8_t address;
  char *command; // Command Received from Master
  uint16_t data[2]; // Data to send to master  
}packet_t;

/* Prototypes */
void packet_send(packet_t *packet);
void packet_read(packet_t *packet);


#endif 
