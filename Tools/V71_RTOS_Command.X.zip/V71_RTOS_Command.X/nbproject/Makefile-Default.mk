#
# Generated Makefile - do not edit!
#
# Edit the Makefile in the project folder instead (../Makefile). Each target
# has a -pre and a -post target defined where you can add customized code.
#
# This makefile implements configuration specific macros and targets.


# Include project Makefile
ifeq "${IGNORE_LOCAL}" "TRUE"
# do not include local makefile. User is passing all local related variables already
else
include Makefile
# Include makefile containing local settings
ifeq "$(wildcard nbproject/Makefile-local-Default.mk)" "nbproject/Makefile-local-Default.mk"
include nbproject/Makefile-local-Default.mk
endif
endif

# Environment
MKDIR=gnumkdir -p
RM=rm -f 
MV=mv 
CP=cp 

# Macros
CND_CONF=Default
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
IMAGE_TYPE=debug
OUTPUT_SUFFIX=elf
DEBUGGABLE_SUFFIX=elf
FINAL_IMAGE=${DISTDIR}/V71_RTOS_Command.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}
else
IMAGE_TYPE=production
OUTPUT_SUFFIX=hex
DEBUGGABLE_SUFFIX=elf
FINAL_IMAGE=${DISTDIR}/V71_RTOS_Command.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}
endif

ifeq ($(COMPARE_BUILD), true)
COMPARISON_BUILD=-mafrlcsj
else
COMPARISON_BUILD=
endif

# Object Directory
OBJECTDIR=build/${CND_CONF}/${IMAGE_TYPE}

# Distribution Directory
DISTDIR=dist/${CND_CONF}/${IMAGE_TYPE}

# Source Files Quoted if spaced
SOURCEFILES_QUOTED_IF_SPACED=examples/driver_examples.c hal/src/hal_atomic.c hal/src/hal_delay.c hal/src/hal_gpio.c hal/src/hal_i2c_m_sync.c hal/src/hal_init.c hal/src/hal_io.c hal/src/hal_sleep.c hal/src/hal_usart_sync.c hal/utils/src/utils_assert.c hal/utils/src/utils_event.c hal/utils/src/utils_list.c hal/utils/src/utils_ringbuffer.c hal/utils/src/utils_syscalls.c hpl/core/hpl_core_m7_base.c hpl/core/hpl_init.c hpl/pmc/hpl_pmc.c hpl/pmc/hpl_sleep.c hpl/twihs/hpl_twihs.c hpl/usart/hpl_usart.c hpl/xdmac/hpl_xdmac.c samv71b/gcc/system_samv71q21b.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.c main.c driver_init.c rtos_start.c atmel_start.c command.c

# Object Files Quoted if spaced
OBJECTFILES_QUOTED_IF_SPACED=${OBJECTDIR}/examples/driver_examples.o ${OBJECTDIR}/hal/src/hal_atomic.o ${OBJECTDIR}/hal/src/hal_delay.o ${OBJECTDIR}/hal/src/hal_gpio.o ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o ${OBJECTDIR}/hal/src/hal_init.o ${OBJECTDIR}/hal/src/hal_io.o ${OBJECTDIR}/hal/src/hal_sleep.o ${OBJECTDIR}/hal/src/hal_usart_sync.o ${OBJECTDIR}/hal/utils/src/utils_assert.o ${OBJECTDIR}/hal/utils/src/utils_event.o ${OBJECTDIR}/hal/utils/src/utils_list.o ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o ${OBJECTDIR}/hal/utils/src/utils_syscalls.o ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o ${OBJECTDIR}/hpl/core/hpl_init.o ${OBJECTDIR}/hpl/pmc/hpl_pmc.o ${OBJECTDIR}/hpl/pmc/hpl_sleep.o ${OBJECTDIR}/hpl/twihs/hpl_twihs.o ${OBJECTDIR}/hpl/usart/hpl_usart.o ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o ${OBJECTDIR}/main.o ${OBJECTDIR}/driver_init.o ${OBJECTDIR}/rtos_start.o ${OBJECTDIR}/atmel_start.o ${OBJECTDIR}/command.o
POSSIBLE_DEPFILES=${OBJECTDIR}/examples/driver_examples.o.d ${OBJECTDIR}/hal/src/hal_atomic.o.d ${OBJECTDIR}/hal/src/hal_delay.o.d ${OBJECTDIR}/hal/src/hal_gpio.o.d ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o.d ${OBJECTDIR}/hal/src/hal_init.o.d ${OBJECTDIR}/hal/src/hal_io.o.d ${OBJECTDIR}/hal/src/hal_sleep.o.d ${OBJECTDIR}/hal/src/hal_usart_sync.o.d ${OBJECTDIR}/hal/utils/src/utils_assert.o.d ${OBJECTDIR}/hal/utils/src/utils_event.o.d ${OBJECTDIR}/hal/utils/src/utils_list.o.d ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o.d ${OBJECTDIR}/hal/utils/src/utils_syscalls.o.d ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o.d ${OBJECTDIR}/hpl/core/hpl_init.o.d ${OBJECTDIR}/hpl/pmc/hpl_pmc.o.d ${OBJECTDIR}/hpl/pmc/hpl_sleep.o.d ${OBJECTDIR}/hpl/twihs/hpl_twihs.o.d ${OBJECTDIR}/hpl/usart/hpl_usart.o.d ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o.d ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o.d ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o.d ${OBJECTDIR}/main.o.d ${OBJECTDIR}/driver_init.o.d ${OBJECTDIR}/rtos_start.o.d ${OBJECTDIR}/atmel_start.o.d ${OBJECTDIR}/command.o.d

# Object Files
OBJECTFILES=${OBJECTDIR}/examples/driver_examples.o ${OBJECTDIR}/hal/src/hal_atomic.o ${OBJECTDIR}/hal/src/hal_delay.o ${OBJECTDIR}/hal/src/hal_gpio.o ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o ${OBJECTDIR}/hal/src/hal_init.o ${OBJECTDIR}/hal/src/hal_io.o ${OBJECTDIR}/hal/src/hal_sleep.o ${OBJECTDIR}/hal/src/hal_usart_sync.o ${OBJECTDIR}/hal/utils/src/utils_assert.o ${OBJECTDIR}/hal/utils/src/utils_event.o ${OBJECTDIR}/hal/utils/src/utils_list.o ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o ${OBJECTDIR}/hal/utils/src/utils_syscalls.o ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o ${OBJECTDIR}/hpl/core/hpl_init.o ${OBJECTDIR}/hpl/pmc/hpl_pmc.o ${OBJECTDIR}/hpl/pmc/hpl_sleep.o ${OBJECTDIR}/hpl/twihs/hpl_twihs.o ${OBJECTDIR}/hpl/usart/hpl_usart.o ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o ${OBJECTDIR}/main.o ${OBJECTDIR}/driver_init.o ${OBJECTDIR}/rtos_start.o ${OBJECTDIR}/atmel_start.o ${OBJECTDIR}/command.o

# Source Files
SOURCEFILES=examples/driver_examples.c hal/src/hal_atomic.c hal/src/hal_delay.c hal/src/hal_gpio.c hal/src/hal_i2c_m_sync.c hal/src/hal_init.c hal/src/hal_io.c hal/src/hal_sleep.c hal/src/hal_usart_sync.c hal/utils/src/utils_assert.c hal/utils/src/utils_event.c hal/utils/src/utils_list.c hal/utils/src/utils_ringbuffer.c hal/utils/src/utils_syscalls.c hpl/core/hpl_core_m7_base.c hpl/core/hpl_init.c hpl/pmc/hpl_pmc.c hpl/pmc/hpl_sleep.c hpl/twihs/hpl_twihs.c hpl/usart/hpl_usart.c hpl/xdmac/hpl_xdmac.c samv71b/gcc/system_samv71q21b.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.c thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.c main.c driver_init.c rtos_start.c atmel_start.c command.c

# Pack Options 
PACK_COMMON_OPTIONS=-I "${CMSIS_DIR}/CMSIS/Core/Include"



CFLAGS=
ASFLAGS=
LDLIBSOPTIONS=

############# Tool locations ##########################################
# If you copy a project from one host to another, the path where the  #
# compiler is installed may be different.                             #
# If you open this project with MPLAB X in the new host, this         #
# makefile will be regenerated and the paths will be corrected.       #
#######################################################################
# fixDeps replaces a bunch of sed/cat/printf statements that slow down the build
FIXDEPS=fixDeps

.build-conf:  ${BUILD_SUBPROJECTS}
ifneq ($(INFORMATION_MESSAGE), )
	@echo $(INFORMATION_MESSAGE)
endif
	${MAKE}  -f nbproject/Makefile-Default.mk ${DISTDIR}/V71_RTOS_Command.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}

MP_PROCESSOR_OPTION=ATSAMV71Q21B
MP_LINKER_FILE_OPTION=
# ------------------------------------------------------------------------------------
# Rules for buildStep: assemble
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: assembleWithPreprocess
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: compile
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
${OBJECTDIR}/examples/driver_examples.o: examples/driver_examples.c  .generated_files/flags/Default/d5c0b7061e8d39d5a5f3a082f6fd566917ed408c .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/examples" 
	@${RM} ${OBJECTDIR}/examples/driver_examples.o.d 
	@${RM} ${OBJECTDIR}/examples/driver_examples.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/examples/driver_examples.o.d" -o ${OBJECTDIR}/examples/driver_examples.o examples/driver_examples.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_atomic.o: hal/src/hal_atomic.c  .generated_files/flags/Default/8096c748d3f916f69eee4d960088783bbf927fba .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_atomic.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_atomic.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_atomic.o.d" -o ${OBJECTDIR}/hal/src/hal_atomic.o hal/src/hal_atomic.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_delay.o: hal/src/hal_delay.c  .generated_files/flags/Default/8c7be7cc52c14ce6de242b08bb06dbad26389c52 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_delay.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_delay.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_delay.o.d" -o ${OBJECTDIR}/hal/src/hal_delay.o hal/src/hal_delay.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_gpio.o: hal/src/hal_gpio.c  .generated_files/flags/Default/79e093ab2fbf5013f39156c0abecde2f70c45dea .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_gpio.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_gpio.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_gpio.o.d" -o ${OBJECTDIR}/hal/src/hal_gpio.o hal/src/hal_gpio.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_i2c_m_sync.o: hal/src/hal_i2c_m_sync.c  .generated_files/flags/Default/a35194a8b965b62743f1ed624a905ac0f5942f17 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_i2c_m_sync.o.d" -o ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o hal/src/hal_i2c_m_sync.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_init.o: hal/src/hal_init.c  .generated_files/flags/Default/626e805e88495517970843dc5e56e2e551e8562d .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_init.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_init.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_init.o.d" -o ${OBJECTDIR}/hal/src/hal_init.o hal/src/hal_init.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_io.o: hal/src/hal_io.c  .generated_files/flags/Default/e1863cf6d5c24e81d92caac86f0e83ae2e15cb81 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_io.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_io.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_io.o.d" -o ${OBJECTDIR}/hal/src/hal_io.o hal/src/hal_io.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_sleep.o: hal/src/hal_sleep.c  .generated_files/flags/Default/7ce729c9430ad5b84934cdeff5e73715b66e2ef5 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_sleep.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_sleep.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_sleep.o.d" -o ${OBJECTDIR}/hal/src/hal_sleep.o hal/src/hal_sleep.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_usart_sync.o: hal/src/hal_usart_sync.c  .generated_files/flags/Default/903ebdea1b39a28e4582d25c10dbb40a299e3462 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_usart_sync.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_usart_sync.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_usart_sync.o.d" -o ${OBJECTDIR}/hal/src/hal_usart_sync.o hal/src/hal_usart_sync.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_assert.o: hal/utils/src/utils_assert.c  .generated_files/flags/Default/17e2262beb8dba603eba48bdd0ece64f1fad1c46 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_assert.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_assert.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_assert.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_assert.o hal/utils/src/utils_assert.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_event.o: hal/utils/src/utils_event.c  .generated_files/flags/Default/8183bf28314a6850920737d2398d6013951a9611 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_event.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_event.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_event.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_event.o hal/utils/src/utils_event.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_list.o: hal/utils/src/utils_list.c  .generated_files/flags/Default/50a22e81d36e3add2030cd71721f4c82a5838657 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_list.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_list.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_list.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_list.o hal/utils/src/utils_list.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o: hal/utils/src/utils_ringbuffer.c  .generated_files/flags/Default/ed4a6d85c14e3a4ee852565339a96904c8ab571 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o hal/utils/src/utils_ringbuffer.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_syscalls.o: hal/utils/src/utils_syscalls.c  .generated_files/flags/Default/16e6956bd2b47ba2f61fb377d53d946ada4d261 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_syscalls.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_syscalls.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_syscalls.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_syscalls.o hal/utils/src/utils_syscalls.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/core/hpl_core_m7_base.o: hpl/core/hpl_core_m7_base.c  .generated_files/flags/Default/8633357153b132039be496ec22ba7043af869056 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/core" 
	@${RM} ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o.d 
	@${RM} ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/core/hpl_core_m7_base.o.d" -o ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o hpl/core/hpl_core_m7_base.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/core/hpl_init.o: hpl/core/hpl_init.c  .generated_files/flags/Default/8cf61eff63004eec350877c748beed34d77b533 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/core" 
	@${RM} ${OBJECTDIR}/hpl/core/hpl_init.o.d 
	@${RM} ${OBJECTDIR}/hpl/core/hpl_init.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/core/hpl_init.o.d" -o ${OBJECTDIR}/hpl/core/hpl_init.o hpl/core/hpl_init.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/pmc/hpl_pmc.o: hpl/pmc/hpl_pmc.c  .generated_files/flags/Default/1def53f5ff61f5a7dab43e12b3c43866a43d23b1 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/pmc" 
	@${RM} ${OBJECTDIR}/hpl/pmc/hpl_pmc.o.d 
	@${RM} ${OBJECTDIR}/hpl/pmc/hpl_pmc.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/pmc/hpl_pmc.o.d" -o ${OBJECTDIR}/hpl/pmc/hpl_pmc.o hpl/pmc/hpl_pmc.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/pmc/hpl_sleep.o: hpl/pmc/hpl_sleep.c  .generated_files/flags/Default/5451761a6c7a823fe5231eff7feca2006990c311 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/pmc" 
	@${RM} ${OBJECTDIR}/hpl/pmc/hpl_sleep.o.d 
	@${RM} ${OBJECTDIR}/hpl/pmc/hpl_sleep.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/pmc/hpl_sleep.o.d" -o ${OBJECTDIR}/hpl/pmc/hpl_sleep.o hpl/pmc/hpl_sleep.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/twihs/hpl_twihs.o: hpl/twihs/hpl_twihs.c  .generated_files/flags/Default/9342e3e13ef9575ce5aa29429425f0a7c3e4994f .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/twihs" 
	@${RM} ${OBJECTDIR}/hpl/twihs/hpl_twihs.o.d 
	@${RM} ${OBJECTDIR}/hpl/twihs/hpl_twihs.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/twihs/hpl_twihs.o.d" -o ${OBJECTDIR}/hpl/twihs/hpl_twihs.o hpl/twihs/hpl_twihs.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/usart/hpl_usart.o: hpl/usart/hpl_usart.c  .generated_files/flags/Default/f44bdc945735876570ef4b5748be563c049440d8 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/usart" 
	@${RM} ${OBJECTDIR}/hpl/usart/hpl_usart.o.d 
	@${RM} ${OBJECTDIR}/hpl/usart/hpl_usart.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/usart/hpl_usart.o.d" -o ${OBJECTDIR}/hpl/usart/hpl_usart.o hpl/usart/hpl_usart.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o: hpl/xdmac/hpl_xdmac.c  .generated_files/flags/Default/a5f4076276fe7a3e6f0e0599bfb213592b4903e3 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/xdmac" 
	@${RM} ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o.d 
	@${RM} ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o.d" -o ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o hpl/xdmac/hpl_xdmac.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o: samv71b/gcc/system_samv71q21b.c  .generated_files/flags/Default/f605283c4c21303d99082349ecfa2fa2e6090745 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/samv71b/gcc" 
	@${RM} ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o.d 
	@${RM} ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o.d" -o ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o samv71b/gcc/system_samv71q21b.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.c  .generated_files/flags/Default/eeb57da6b408607a45c61207860462a4c311d0bc .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.c  .generated_files/flags/Default/e2d35e33dcf312ea184d512262b5df37870d5f97 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.c  .generated_files/flags/Default/24201f12adc16fd0be2656ae15df7649075a2b11 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.c  .generated_files/flags/Default/6374bb45baeb5cdd4f70d0041470d484b36e5399 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.c  .generated_files/flags/Default/bbccf47cee8994a10a0a0910cb56c83187130289 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.c  .generated_files/flags/Default/6053f8cdb538e358e18587939b7aebab33e64975 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.c  .generated_files/flags/Default/e9dbcd8493805a8dd8c4709af1cf91bc1e318889 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.c  .generated_files/flags/Default/aa863eb8923481c6ae6d336834b5cba8c856ef7c .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.c  .generated_files/flags/Default/dc5e2beb37ab56e530fb192068723e4d6361e44a .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.c  .generated_files/flags/Default/c6d9b1b5a4def18b22abf47197848fd918220d71 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/main.o: main.c  .generated_files/flags/Default/e51512c4cfb0cc7fe4880ea98b0db413d49c9fe4 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/main.o.d 
	@${RM} ${OBJECTDIR}/main.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/main.o.d" -o ${OBJECTDIR}/main.o main.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/driver_init.o: driver_init.c  .generated_files/flags/Default/809d220eacc78cab0b9051b104e756bf6a298e51 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/driver_init.o.d 
	@${RM} ${OBJECTDIR}/driver_init.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/driver_init.o.d" -o ${OBJECTDIR}/driver_init.o driver_init.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/rtos_start.o: rtos_start.c  .generated_files/flags/Default/cb281a81afa2e7c1648d95fd4e46beaed386cbce .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/rtos_start.o.d 
	@${RM} ${OBJECTDIR}/rtos_start.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/rtos_start.o.d" -o ${OBJECTDIR}/rtos_start.o rtos_start.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/atmel_start.o: atmel_start.c  .generated_files/flags/Default/8df8ac9dca78a75ff07dc004cb140cae18975c98 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/atmel_start.o.d 
	@${RM} ${OBJECTDIR}/atmel_start.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/atmel_start.o.d" -o ${OBJECTDIR}/atmel_start.o atmel_start.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/command.o: command.c  .generated_files/flags/Default/90dcd87a32c10211de15ff667b85f98680a5df6b .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/command.o.d 
	@${RM} ${OBJECTDIR}/command.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE) -g -D__DEBUG   -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/command.o.d" -o ${OBJECTDIR}/command.o command.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
else
${OBJECTDIR}/examples/driver_examples.o: examples/driver_examples.c  .generated_files/flags/Default/370dcf823b1761eab052e074269869f3f2bc3df4 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/examples" 
	@${RM} ${OBJECTDIR}/examples/driver_examples.o.d 
	@${RM} ${OBJECTDIR}/examples/driver_examples.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/examples/driver_examples.o.d" -o ${OBJECTDIR}/examples/driver_examples.o examples/driver_examples.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_atomic.o: hal/src/hal_atomic.c  .generated_files/flags/Default/36297766f3aac207453bd38bd2279bfe3ea7fb62 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_atomic.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_atomic.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_atomic.o.d" -o ${OBJECTDIR}/hal/src/hal_atomic.o hal/src/hal_atomic.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_delay.o: hal/src/hal_delay.c  .generated_files/flags/Default/2339a60f46617f7b009b2193499c78f02b3e895f .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_delay.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_delay.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_delay.o.d" -o ${OBJECTDIR}/hal/src/hal_delay.o hal/src/hal_delay.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_gpio.o: hal/src/hal_gpio.c  .generated_files/flags/Default/f65dadd37a1192ff0609fdccf30770f4065cf58b .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_gpio.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_gpio.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_gpio.o.d" -o ${OBJECTDIR}/hal/src/hal_gpio.o hal/src/hal_gpio.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_i2c_m_sync.o: hal/src/hal_i2c_m_sync.c  .generated_files/flags/Default/15518e47e7d57669fbcec9ebc75c44b895e99f17 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_i2c_m_sync.o.d" -o ${OBJECTDIR}/hal/src/hal_i2c_m_sync.o hal/src/hal_i2c_m_sync.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_init.o: hal/src/hal_init.c  .generated_files/flags/Default/a84bb8e2328fd801ba0e7d3e3c9fa11a3be406c4 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_init.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_init.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_init.o.d" -o ${OBJECTDIR}/hal/src/hal_init.o hal/src/hal_init.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_io.o: hal/src/hal_io.c  .generated_files/flags/Default/1e05157c9b0925858f8e4e3a11e5b3ef8c3c0960 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_io.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_io.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_io.o.d" -o ${OBJECTDIR}/hal/src/hal_io.o hal/src/hal_io.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_sleep.o: hal/src/hal_sleep.c  .generated_files/flags/Default/94dbf4de49901308f60b32cd27df065ac34245e .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_sleep.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_sleep.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_sleep.o.d" -o ${OBJECTDIR}/hal/src/hal_sleep.o hal/src/hal_sleep.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/src/hal_usart_sync.o: hal/src/hal_usart_sync.c  .generated_files/flags/Default/55fd0dd0849c300ecb0aaf249b56421bc49b37f5 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/src" 
	@${RM} ${OBJECTDIR}/hal/src/hal_usart_sync.o.d 
	@${RM} ${OBJECTDIR}/hal/src/hal_usart_sync.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/src/hal_usart_sync.o.d" -o ${OBJECTDIR}/hal/src/hal_usart_sync.o hal/src/hal_usart_sync.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_assert.o: hal/utils/src/utils_assert.c  .generated_files/flags/Default/7dbb9e6f54d351752f8be7df9749c74a9164a2a1 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_assert.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_assert.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_assert.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_assert.o hal/utils/src/utils_assert.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_event.o: hal/utils/src/utils_event.c  .generated_files/flags/Default/843ce3b81fa3b419325cf982b34a38cdf867fa34 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_event.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_event.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_event.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_event.o hal/utils/src/utils_event.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_list.o: hal/utils/src/utils_list.c  .generated_files/flags/Default/d3b8d965a75ba80a74577fa3fc950f27992ae8cb .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_list.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_list.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_list.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_list.o hal/utils/src/utils_list.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o: hal/utils/src/utils_ringbuffer.c  .generated_files/flags/Default/142ab99d6f43b470eabab042541f06bd12f9a2c4 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_ringbuffer.o hal/utils/src/utils_ringbuffer.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hal/utils/src/utils_syscalls.o: hal/utils/src/utils_syscalls.c  .generated_files/flags/Default/e9b6a2f7610ff2e413ebde46cc8b17b7c636a3fe .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hal/utils/src" 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_syscalls.o.d 
	@${RM} ${OBJECTDIR}/hal/utils/src/utils_syscalls.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hal/utils/src/utils_syscalls.o.d" -o ${OBJECTDIR}/hal/utils/src/utils_syscalls.o hal/utils/src/utils_syscalls.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/core/hpl_core_m7_base.o: hpl/core/hpl_core_m7_base.c  .generated_files/flags/Default/b2298140e8a20d3b996650ffe6bd1eeff39e1d1c .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/core" 
	@${RM} ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o.d 
	@${RM} ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/core/hpl_core_m7_base.o.d" -o ${OBJECTDIR}/hpl/core/hpl_core_m7_base.o hpl/core/hpl_core_m7_base.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/core/hpl_init.o: hpl/core/hpl_init.c  .generated_files/flags/Default/706c5151eff05b665ff39323b5ccf2cf5ed4d6db .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/core" 
	@${RM} ${OBJECTDIR}/hpl/core/hpl_init.o.d 
	@${RM} ${OBJECTDIR}/hpl/core/hpl_init.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/core/hpl_init.o.d" -o ${OBJECTDIR}/hpl/core/hpl_init.o hpl/core/hpl_init.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/pmc/hpl_pmc.o: hpl/pmc/hpl_pmc.c  .generated_files/flags/Default/83cfe66786c1b02d77a37e445115ba8ce4d5b6c5 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/pmc" 
	@${RM} ${OBJECTDIR}/hpl/pmc/hpl_pmc.o.d 
	@${RM} ${OBJECTDIR}/hpl/pmc/hpl_pmc.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/pmc/hpl_pmc.o.d" -o ${OBJECTDIR}/hpl/pmc/hpl_pmc.o hpl/pmc/hpl_pmc.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/pmc/hpl_sleep.o: hpl/pmc/hpl_sleep.c  .generated_files/flags/Default/331651f11e0c568ca1129414fd6b0c95ddb9bb96 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/pmc" 
	@${RM} ${OBJECTDIR}/hpl/pmc/hpl_sleep.o.d 
	@${RM} ${OBJECTDIR}/hpl/pmc/hpl_sleep.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/pmc/hpl_sleep.o.d" -o ${OBJECTDIR}/hpl/pmc/hpl_sleep.o hpl/pmc/hpl_sleep.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/twihs/hpl_twihs.o: hpl/twihs/hpl_twihs.c  .generated_files/flags/Default/af4843031a8f8edfe1b94de0e0f450242abaea57 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/twihs" 
	@${RM} ${OBJECTDIR}/hpl/twihs/hpl_twihs.o.d 
	@${RM} ${OBJECTDIR}/hpl/twihs/hpl_twihs.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/twihs/hpl_twihs.o.d" -o ${OBJECTDIR}/hpl/twihs/hpl_twihs.o hpl/twihs/hpl_twihs.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/usart/hpl_usart.o: hpl/usart/hpl_usart.c  .generated_files/flags/Default/da8caa532f1320d3d413c9ad6be7de1c64deab68 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/usart" 
	@${RM} ${OBJECTDIR}/hpl/usart/hpl_usart.o.d 
	@${RM} ${OBJECTDIR}/hpl/usart/hpl_usart.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/usart/hpl_usart.o.d" -o ${OBJECTDIR}/hpl/usart/hpl_usart.o hpl/usart/hpl_usart.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o: hpl/xdmac/hpl_xdmac.c  .generated_files/flags/Default/f1a7e106bd5509edcc40643a10ec64035f7b750c .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/hpl/xdmac" 
	@${RM} ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o.d 
	@${RM} ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o.d" -o ${OBJECTDIR}/hpl/xdmac/hpl_xdmac.o hpl/xdmac/hpl_xdmac.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o: samv71b/gcc/system_samv71q21b.c  .generated_files/flags/Default/4ea8eb80f41abb8faaa20983d93be2e78ea3b54f .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/samv71b/gcc" 
	@${RM} ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o.d 
	@${RM} ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o.d" -o ${OBJECTDIR}/samv71b/gcc/system_samv71q21b.o samv71b/gcc/system_samv71q21b.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.c  .generated_files/flags/Default/7ec61a1362f13d6ccd9789aefecc6d6a559ce1e6 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/port.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.c  .generated_files/flags/Default/f96c9d39a6a1e124abab70aa90a7acb8e754ef12 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/MemMang/heap_1.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.c  .generated_files/flags/Default/48ab9b66d52bba675e92db75bc406a128076adf9 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/croutine.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.c  .generated_files/flags/Default/c9058075878792e82e0bcaabf6e5b11bd1495b27 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/event_groups.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.c  .generated_files/flags/Default/a366dcd7e45ac7154074d601287efc7535e88330 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/list.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.c  .generated_files/flags/Default/804f32431f6661d7b5846eaf6a6f9332efd00794 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/queue.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.c  .generated_files/flags/Default/5494606f100bd1a68e85608f5950f07dc0a29c57 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/stream_buffer.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.c  .generated_files/flags/Default/c0c302b709db88297bfb3279b0efbbd5ab64daf0 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/tasks.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.c  .generated_files/flags/Default/c224e95f42aaf1dd63da296644be906ba5388904 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/timers.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o: thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.c  .generated_files/flags/Default/8f3d837145bab55160cd9736b33ba1e07f1428f4 .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0" 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o.d 
	@${RM} ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o.d" -o ${OBJECTDIR}/thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.o thirdparty/RTOS/freertos/FreeRTOSV10.0.0/rtos_port.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/main.o: main.c  .generated_files/flags/Default/9a53b5a4eb427632af3af145821188a74b34fdfc .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/main.o.d 
	@${RM} ${OBJECTDIR}/main.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/main.o.d" -o ${OBJECTDIR}/main.o main.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/driver_init.o: driver_init.c  .generated_files/flags/Default/3628d027699bd5c64b5a3c583bc0951a2e62505a .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/driver_init.o.d 
	@${RM} ${OBJECTDIR}/driver_init.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/driver_init.o.d" -o ${OBJECTDIR}/driver_init.o driver_init.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/rtos_start.o: rtos_start.c  .generated_files/flags/Default/c3998c72a53cec1294b2374259caf97b65f7c20f .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/rtos_start.o.d 
	@${RM} ${OBJECTDIR}/rtos_start.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/rtos_start.o.d" -o ${OBJECTDIR}/rtos_start.o rtos_start.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/atmel_start.o: atmel_start.c  .generated_files/flags/Default/daaac1804d7a6aaab9ef1207b3e852ae571987be .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/atmel_start.o.d 
	@${RM} ${OBJECTDIR}/atmel_start.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/atmel_start.o.d" -o ${OBJECTDIR}/atmel_start.o atmel_start.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
${OBJECTDIR}/command.o: command.c  .generated_files/flags/Default/4fdd2263f94317add73c57cd734cd476d008d37f .generated_files/flags/Default/da39a3ee5e6b4b0d3255bfef95601890afd80709
	@${MKDIR} "${OBJECTDIR}" 
	@${RM} ${OBJECTDIR}/command.o.d 
	@${RM} ${OBJECTDIR}/command.o 
	${MP_CC}  $(MP_EXTRA_CC_PRE)  -g -x c -c -mprocessor=$(MP_PROCESSOR_OPTION)  -I"config" -I"examples" -I"hal/include" -I"hal/utils/include" -I"hpl/core" -I"hpl/pio" -I"hpl/pmc" -I"hpl/twihs" -I"hpl/usart" -I"hpl/xdmac" -I"hri" -I"thirdparty/RTOS" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7" -I"thirdparty/RTOS/freertos/FreeRTOSV10.0.0/module_config" -I"CMSIS/Core/Include" -I"samv71b/include" -I"./." -O0 -MP -MMD -MF "${OBJECTDIR}/command.o.d" -o ${OBJECTDIR}/command.o command.c    -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -mdfp="${DFP_DIR}/samv71b" ${PACK_COMMON_OPTIONS} 
	
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: compileCPP
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: link
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
${DISTDIR}/V71_RTOS_Command.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}: ${OBJECTFILES}  nbproject/Makefile-${CND_CONF}.mk    
	@${MKDIR} ${DISTDIR} 
	${MP_CC} $(MP_EXTRA_LD_PRE) -g   -mprocessor=$(MP_PROCESSOR_OPTION)  -o ${DISTDIR}/V71_RTOS_Command.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX} ${OBJECTFILES_QUOTED_IF_SPACED}          -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -Wl,--defsym=__MPLAB_BUILD=1$(MP_EXTRA_LD_POST)$(MP_LINKER_FILE_OPTION),--defsym=__ICD2RAM=1,--defsym=__MPLAB_DEBUG=1,--defsym=__DEBUG=1,-D=__DEBUG_D,-L"samv71b/gcc/gcc",-Map="${DISTDIR}/${PROJECTNAME}.${IMAGE_TYPE}.map",--memorysummary,${DISTDIR}/memoryfile.xml -mdfp="${DFP_DIR}/samv71b"
	
else
${DISTDIR}/V71_RTOS_Command.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}: ${OBJECTFILES}  nbproject/Makefile-${CND_CONF}.mk   
	@${MKDIR} ${DISTDIR} 
	${MP_CC} $(MP_EXTRA_LD_PRE)  -mprocessor=$(MP_PROCESSOR_OPTION)  -o ${DISTDIR}/V71_RTOS_Command.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX} ${OBJECTFILES_QUOTED_IF_SPACED}          -DXPRJ_Default=$(CND_CONF)    $(COMPARISON_BUILD)  -Wl,--defsym=__MPLAB_BUILD=1$(MP_EXTRA_LD_POST)$(MP_LINKER_FILE_OPTION),-L"samv71b/gcc/gcc",-Map="${DISTDIR}/${PROJECTNAME}.${IMAGE_TYPE}.map",--memorysummary,${DISTDIR}/memoryfile.xml -mdfp="${DFP_DIR}/samv71b"
	${MP_CC_DIR}\\xc32-bin2hex ${DISTDIR}/V71_RTOS_Command.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX} 
endif


# Subprojects
.build-subprojects:


# Subprojects
.clean-subprojects:

# Clean Targets
.clean-conf: ${CLEAN_SUBPROJECTS}
	${RM} -r ${OBJECTDIR}
	${RM} -r ${DISTDIR}

# Enable dependency checking
.dep.inc: .depcheck-impl

DEPFILES=$(wildcard ${POSSIBLE_DEPFILES})
ifneq (${DEPFILES},)
include ${DEPFILES}
endif
