#include "command.h"

void packet_send(packet_t *packet){
    // Set Address
    i2c_m_sync_set_slaveaddr(
        &command, 
        packet->address, 
        I2C_M_SEVEN
    ); 
    
    // Transmit
    io_write(
        command_io,
        (uint8_t*)packet->command, 
        strlen(packet->command)+1
    );
    
}

void packet_read(packet_t *packet){
    // Set Address to be read from
    uint8_t address = (packet->address << 1) | 0x01;
    io_write(command_io, address,1); 
    
    // Receive 4 bytes
    uint8_t data[4];
    io_read(command_io,data,4);
    
    // Store into packets
    for(int i=0;i<2;i++){
        packet->data[i] = data[1+2*i]/data[2*i];
    }
}
