/* Headers */
#include <atmel_start.h>
#include "driver_init.h"
#include "command.h"


/* Globals */
int main(void)
{
    // Initialize all Peripheral 
	atmel_start_init();
    
    // Initialize variable
    char message[100];
    
    // Initialize Packet
    packet_t packet = {
        .address = COMMAND_ADDRESS,
        .command = "Initialize",
        .data = {0x0000, 0x0000}
    };
    packet_send(&packet);
    
    // Reading Loop
    while(1){
        // Read Channel 1
        packet.command = "Read Channel 1";
        packet_send(&packet);
        delay_ms(100);
        packet_read(&packet);
        delay_ms(100);
        
        // Read Channel 0
        packet.command = "Read Channel 0";
        packet_send(&packet);
        delay_ms(100);
        packet_read(&packet);
        delay_ms(100);
        
        // Print Packets
        snprintf(message,100,"Channel 0 : %d\n",packet.data[0]);
        io_write(serial_io,(uint8_t *)message,strlen(message));
        
        snprintf(message,100,"Channel 1 : %d\n",packet.data[1]);
        io_write(serial_io,(uint8_t *)message,strlen(message));
        
        // Delay
        delay_ms(100);
    }
    
}
