// #cmakedefine01 CSP_POSIX
// #cmakedefine01 CSP_ZEPHYR
// #cmakedefine01 CSP_FREERTOS

// #cmakedefine01 CSP_HAVE_STDIO
// #cmakedefine01 CSP_ENABLE_CSP_PRINT
// #cmakedefine01 CSP_PRINT_STDIO

// #cmakedefine01 CSP_REPRODUCIBLE_BUILDS

// #cmakedefine CSP_QFIFO_LEN @CSP_QFIFO_LEN@
// #cmakedefine CSP_PORT_MAX_BIND @CSP_PORT_MAX_BIND@
// #cmakedefine CSP_CONN_RXQUEUE_LEN @CSP_CONN_RXQUEUE_LEN@
// #cmakedefine CSP_CONN_MAX @CSP_CONN_MAX@
// #cmakedefine CSP_BUFFER_SIZE @CSP_BUFFER_SIZE@
// #cmakedefine CSP_BUFFER_COUNT @CSP_BUFFER_COUNT@
// #cmakedefine CSP_RDP_MAX_WINDOW @CSP_RDP_MAX_WINDOW@
// #cmakedefine CSP_RTABLE_SIZE @CSP_RTABLE_SIZE@

// #cmakedefine01 CSP_USE_RDP
// #cmakedefine01 CSP_USE_HMAC
// #cmakedefine01 CSP_USE_PROMISC
// #cmakedefine01 CSP_USE_RTABLE
// #cmakedefine01 CSP_BUFFER_ZERO_CLEAR

// #cmakedefine01 CSP_HAVE_LIBSOCKETCAN
// #cmakedefine01 CSP_HAVE_LIBZMQ

// #cmakedefine01 CSP_FIXUP_V1_ZMQ_LITTLE_ENDIAN

#define CSP_FREERTOS    1

// Required buffer configuration
#define CSP_BUFFER_SIZE        300     // Minimum recommended size
#define CSP_BUFFER_COUNT       10      // Tune based on available RAM

// Required connection configuration
#define CSP_CONN_MAX           5       // Number of simultaneous connections

// Required queue configuration
#define CSP_CONN_RXQUEUE_LEN   2       // RX queue per connection
#define CSP_QFIFO_LEN          5       // Queue size per socket

// Port binding
#define CSP_PORT_MAX_BIND      5       // Max ports that can be bound
