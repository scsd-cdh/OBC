thirdparty/LIBCSP/src/arch/freertos/csp_semaphore.d \
 thirdparty/LIBCSP/src/arch/freertos/csp_semaphore.o: \
 ../thirdparty/LIBCSP/src/arch/freertos/csp_semaphore.c \
 ../thirdparty/LIBCSP/src/arch/freertos/../../csp_semaphore.h \
 ../thirdparty/LIBCSP/include/csp/autoconfig.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/FreeRTOS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stddef.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_default_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\features.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_newlib_version.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_intsup.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_stdint.h \
 ../Config/FreeRTOSConfig.h ../Config/peripheral_clk_config.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/projdefs.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/portable.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/deprecated_definitions.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/portmacro.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/mpu_wrappers.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/task.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/list.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/semphr.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/queue.h \
 ../thirdparty/LIBCSP/include/csp/csp_debug.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\inttypes.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\newlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\config.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\ieeefp.h \
 ../thirdparty/LIBCSP/include/csp/csp.h \
 ../thirdparty/LIBCSP/include/csp/csp_error.h \
 ../thirdparty/LIBCSP/include/csp/csp_buffer.h \
 ../thirdparty/LIBCSP/include/csp/csp_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdbool.h \
 ../thirdparty/LIBCSP/include/csp/arch/csp_queue.h \
 ../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/queue.h \
 ../thirdparty/LIBCSP/include/csp/csp_rtable.h \
 ../thirdparty/LIBCSP/include/csp/csp_iflist.h \
 ../thirdparty/LIBCSP/include/csp/csp_interface.h \
 ../thirdparty/LIBCSP/include/csp/csp_sfp.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\string.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_ansi.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\reent.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_ansi.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\lock.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\cdefs.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\xlocale.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\string.h \
 ../thirdparty/LIBCSP/include/csp/csp_promisc.h

../thirdparty/LIBCSP/src/arch/freertos/../../csp_semaphore.h:

../thirdparty/LIBCSP/include/csp/autoconfig.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/FreeRTOS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stddef.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_default_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\features.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_newlib_version.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_intsup.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_stdint.h:

../Config/FreeRTOSConfig.h:

../Config/peripheral_clk_config.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/projdefs.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/portable.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/deprecated_definitions.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/portable/GCC/ARM_CM7/portmacro.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/mpu_wrappers.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/task.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/list.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/semphr.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/queue.h:

../thirdparty/LIBCSP/include/csp/csp_debug.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\inttypes.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\newlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\config.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\ieeefp.h:

../thirdparty/LIBCSP/include/csp/csp.h:

../thirdparty/LIBCSP/include/csp/csp_error.h:

../thirdparty/LIBCSP/include/csp/csp_buffer.h:

../thirdparty/LIBCSP/include/csp/csp_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\lib\gcc\arm-none-eabi\6.3.1\include\stdbool.h:

../thirdparty/LIBCSP/include/csp/arch/csp_queue.h:

../thirdparty/RTOS/freertos/FreeRTOSV10.0.0/Source/include/queue.h:

../thirdparty/LIBCSP/include/csp/csp_rtable.h:

../thirdparty/LIBCSP/include/csp/csp_iflist.h:

../thirdparty/LIBCSP/include/csp/csp_interface.h:

../thirdparty/LIBCSP/include/csp/csp_sfp.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\string.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_ansi.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\reent.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\_ansi.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\machine\_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\lock.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\cdefs.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\xlocale.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\arm-gnu-toolchain\arm-none-eabi\include\sys\string.h:

../thirdparty/LIBCSP/include/csp/csp_promisc.h:
